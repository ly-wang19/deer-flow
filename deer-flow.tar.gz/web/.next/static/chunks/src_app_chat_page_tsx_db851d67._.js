(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_chat_main_tsx_d3923d31._.js",
  "static/chunks/src_04b673e0._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_zod_dist_esm_fc28aa98._.js",
  "static/chunks/node_modules_micromark-core-commonmark_dev_lib_36a4b45d._.js",
  "static/chunks/node_modules_katex_dist_katex_mjs_196a355b._.js",
  "static/chunks/node_modules_framer-motion_dist_es_24e93cb0._.js",
  "static/chunks/node_modules_motion-dom_dist_es_fa3ea29e._.js",
  "static/chunks/node_modules_@radix-ui_1166d0db._.js",
  "static/chunks/node_modules_@floating-ui_9ec1fa39._.js",
  "static/chunks/node_modules_87ecbfca._.js",
  "static/chunks/node_modules_katex_dist_katex_min_f5e99d99.css"
],
    source: "dynamic"
});
