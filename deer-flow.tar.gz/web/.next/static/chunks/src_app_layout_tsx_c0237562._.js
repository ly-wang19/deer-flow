(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__698e6b9e._.css",
  "static/chunks/node_modules_f8f0c5fa._.js",
  "static/chunks/src_components_6ddcf391._.js"
],
    source: "dynamic"
});
