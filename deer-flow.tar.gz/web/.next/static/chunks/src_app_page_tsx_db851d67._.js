(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_motion_dist_es_9f761d99._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_@xyflow_system_dist_esm_index_23fcde8d.js",
  "static/chunks/node_modules_@xyflow_react_dist_esm_index_07812fd7.js",
  "static/chunks/node_modules_bf8b6237._.js",
  "static/chunks/src_2d32a275._.js",
  "static/chunks/node_modules_@xyflow_react_dist_style_2bb086ca.css"
],
    source: "dynamic"
});
