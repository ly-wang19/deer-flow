(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/chat/main.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_b71ee4ad._.js",
  "static/chunks/node_modules_prosemirror-view_dist_index_212d9a9b.js",
  "static/chunks/node_modules_@tiptap_core_dist_index_bbf02861.js",
  "static/chunks/node_modules_@popperjs_core_lib_e7041586._.js",
  "static/chunks/node_modules_react-moveable_dist_moveable_esm_fbea2d59.js",
  "static/chunks/node_modules_react-tweet_dist_1f41c8f5._.js",
  "static/chunks/node_modules_entities_lib_esm_3b43f604._.js",
  "static/chunks/node_modules_markdown-it_c9117e0a._.js",
  "static/chunks/c23ac_highlight_js_lib_languages_mathematica_b6ea9ca4.js",
  "static/chunks/c23ac_highlight_js_lib_languages_9ea41169._.js",
  "static/chunks/c23ac_highlight_js_lib_core_b6fb72f9.js",
  "static/chunks/node_modules_highlight_js_es_c76ee030._.js",
  "static/chunks/node_modules_highlight_js_lib_languages_mathematica_b6fce4e3.js",
  "static/chunks/node_modules_highlight_js_lib_languages_ab329a1b._.js",
  "static/chunks/node_modules_highlight_js_lib_4fa2e2b9._.js",
  "static/chunks/node_modules_@tiptap_55981987._.js",
  "static/chunks/node_modules_@radix-ui_a84e2e31._.js",
  "static/chunks/node_modules_9853f54c._.js",
  {
    "path": "static/chunks/_3706da15._.css",
    "included": [
      "[project]/src/components/deer-flow/rainbow-text.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-container.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/theme.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-header.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/icons/icons.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/verified-badge.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-in-reply-to.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-link.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-body.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-media.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-media-video.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-info-created-at.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-info.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-actions.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-replies.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/quoted-tweet/quoted-tweet-container.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/quoted-tweet/quoted-tweet-header.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/quoted-tweet/quoted-tweet-body.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-not-found.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/skeleton.module.css [app-client] (css)",
      "[project]/node_modules/react-tweet/dist/twitter-theme/tweet-skeleton.module.css [app-client] (css)",
      "[project]/src/styles/prosemirror.css [app-client] (css)",
      "[project]/src/components/deer-flow/loading-animation.module.css [app-client] (css)"
    ],
    "moduleChunks": [
      "static/chunks/src_components_deer-flow_rainbow-text_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_tweet-container_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_theme_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_tweet-header_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_icons_icons_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_verified-badge_module_css_f9ee138c._.single.css",
      "static/chunks/dd92d_modules_react-tweet_dist_twitter-theme_tweet-in-reply-to_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_tweet-link_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_tweet-body_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_tweet-media_module_css_f9ee138c._.single.css",
      "static/chunks/dd92d_modules_react-tweet_dist_twitter-theme_tweet-media-video_module_css_f9ee138c._.single.css",
      "static/chunks/8069e_react-tweet_dist_twitter-theme_tweet-info-created-at_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_tweet-info_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_tweet-actions_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_tweet-replies_module_css_f9ee138c._.single.css",
      "static/chunks/f9d18_dist_twitter-theme_quoted-tweet_quoted-tweet-container_module_css_f9ee138c._.single.css",
      "static/chunks/f9d18_dist_twitter-theme_quoted-tweet_quoted-tweet-header_module_css_f9ee138c._.single.css",
      "static/chunks/f9d18_dist_twitter-theme_quoted-tweet_quoted-tweet-body_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_tweet-not-found_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_skeleton_module_css_f9ee138c._.single.css",
      "static/chunks/node_modules_react-tweet_dist_twitter-theme_tweet-skeleton_module_css_f9ee138c._.single.css",
      "static/chunks/src_styles_prosemirror_css_f9ee138c._.single.css",
      "static/chunks/src_components_deer-flow_loading-animation_module_css_f9ee138c._.single.css"
    ]
  },
  "static/chunks/src_app_chat_main_tsx_67281f2a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/chat/main.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);