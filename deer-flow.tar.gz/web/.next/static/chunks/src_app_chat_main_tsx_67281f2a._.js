(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b71ee4ad._.js",
  "static/chunks/node_modules_prosemirror-view_dist_index_212d9a9b.js",
  "static/chunks/node_modules_@tiptap_core_dist_index_bbf02861.js",
  "static/chunks/node_modules_@popperjs_core_lib_e7041586._.js",
  "static/chunks/node_modules_react-moveable_dist_moveable_esm_fbea2d59.js",
  "static/chunks/node_modules_react-tweet_dist_1f41c8f5._.js",
  "static/chunks/node_modules_entities_lib_esm_3b43f604._.js",
  "static/chunks/node_modules_markdown-it_c9117e0a._.js",
  "static/chunks/c23ac_highlight_js_lib_languages_mathematica_b6ea9ca4.js",
  "static/chunks/c23ac_highlight_js_lib_languages_9ea41169._.js",
  "static/chunks/c23ac_highlight_js_lib_core_b6fb72f9.js",
  "static/chunks/node_modules_highlight_js_es_c76ee030._.js",
  "static/chunks/node_modules_highlight_js_lib_languages_mathematica_b6fce4e3.js",
  "static/chunks/node_modules_highlight_js_lib_languages_ab329a1b._.js",
  "static/chunks/node_modules_highlight_js_lib_4fa2e2b9._.js",
  "static/chunks/node_modules_@tiptap_55981987._.js",
  "static/chunks/node_modules_@radix-ui_a84e2e31._.js",
  "static/chunks/node_modules_9853f54c._.js",
  "static/chunks/_3706da15._.css"
],
    source: "dynamic"
});
